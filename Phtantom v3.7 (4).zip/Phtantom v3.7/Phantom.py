import os
import tempfile
import subprocess

hta_content = r"""
<html><head><title>Phantom Executor</title>
<style>
body{background:#050608;color:#00ffea;font-family:Consolas;font-size:14px;}
#log{width:95%;height:300px;background:#000;border:1px solid #00ffea;padding:10px;overflow:auto;}
#input{width:95%;height:120px;background:#000;border:1px solid #00ffea;color:#00ffea;font-family:Consolas;}
button{background:#00ffea;color:#000;font-weight:bold;border:0;padding:10px;margin-top:10px;cursor:pointer;margin-right:5px;}
</style>
</head><body>

<h2>Phantom Executor v3.7</h2>
<div id='log'></div>
<textarea id='input' placeholder='Insere ton script ici...'></textarea><br>

<button id='btnInject'>Inject</button>
<button id='btnExecute'>Execute</button>

<script>
function log(t){
  var l = document.getElementById("log");
  l.innerHTML += t + "<br>";
  l.scrollTop = l.scrollHeight;
}

function isEmpty(s){
  return s.replace(/^\s+|\s+$/g,"") === "";
}

function inject(){
  var steps = [
    "[INJECT] Ouverture du handle Roblox.exe",
    "[INJECT] Scan des modules charges...",
    "[INJECT] Localisation de RobloxPlayerBeta.exe",
    "[INJECT] Chargement de PhantomCore.dll",
    "[INJECT] Resolution des offsets...",
    "[INJECT] Patch des fonctions de securite...",
    "[INJECT] Allocation de la memoire distante...",
    "[INJECT] Ecriture du payload...",
    "[INJECT] Creation du thread distant...",
    "[INJECT] Injection terminee."
  ];

  for(var i=0;i<steps.length;i++){
    (function(msg,delay){
      setTimeout(function(){ log(msg); }, delay);
    })(steps[i], i*250);
  }
}

function executeScript(){
  var s = document.getElementById("input").value;
  if(isEmpty(s)){
    log("[ERROR] Aucun script detecte");
    return;
  }
  log("[EXEC] Script charge");
  setTimeout(function(){ log("[EXEC] Analyse du script..."); }, 300);
  setTimeout(function(){ log("[EXEC] Compilation des instructions..."); }, 700);
  setTimeout(function(){ log("[EXEC] Liaison avec le contexte Roblox..."); }, 1100);
  setTimeout(function(){ log("[EXEC] Execution en cours..."); }, 1500);
  setTimeout(function(){ log("[EXEC] Script execute avec succes"); }, 2000);
}

window.onload = function(){
  log("Initialisation du noyau PhantomCore.dll");
  setTimeout(function(){ log("Chargement des modules de base..."); }, 300);
  setTimeout(function(){ log("Preparation de l'environnement Roblox..."); }, 600);
  setTimeout(function(){ log("Environnement pret. En attente d'injection."); }, 900);

  document.getElementById("btnInject").onclick = inject;
  document.getElementById("btnExecute").onclick = executeScript;
}
</script>

</body></html>
"""

# Crée un fichier temporaire .hta
hta_path = os.path.join(tempfile.gettempdir(), "phantom_exec.hta")

with open(hta_path, "w", encoding="utf-8") as f:
    f.write(hta_content)

# Lance mshta.exe
subprocess.run(["mshta.exe", hta_path])